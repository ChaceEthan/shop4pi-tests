# Fix rights of /tmp (can be a volume)
chmod 1777 /tmp
