#!/usr/bin/env bash

## remove logs (each bootstrap)
rm -rf -- /var/log/*
rm -rf -- /var/tmp/*
rm -rf -- /tmp/*
rm -rf -- /root/.profile
